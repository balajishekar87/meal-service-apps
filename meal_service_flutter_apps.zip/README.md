# Meal Service Mobile Apps (iOS & Android — Flutter)

Two cross-platform Flutter applications for managing a daily meal subscription service (Breakfast, Lunch, and Dinner) for ~200 customers/day:

1. **`customer_app/`** — Customer Meal Booking & Wallet App
2. **`admin_app/`** — Kitchen & Admin Preparation Dashboard App

---

## Business Rules Implemented
- **Meals & Nominal Pricing** (configurable in `lib/models/meal_models.dart`):
  - Breakfast: ₹40 | Lunch: ₹70 | Dinner: ₹70 (Total ₹180/day; Monthly Advance ₹5,400 for 30 days)
- **Previous-Day 8:00 PM Cutoff**:
  - Customers can toggle Breakfast, Lunch, or Dinner—or mark a full **Day Off**—for **tomorrow** until **8:00 PM today**.
  - After 8:00 PM, tomorrow's selections lock for kitchen preparation, and edits apply to the day after tomorrow.
- **Monthly Advance Cash & Wallet Refunds**:
  - Customers pay cash in advance for the month.
  - Whenever a customer skips a meal or takes a day off before the 8:00 PM cutoff, the nominal cost of those skipped meals is automatically **credited to their Wallet**.

---

## Prerequisites & Setup (iOS & Android)

1. Install **Flutter SDK** (3.19+ recommended): https://docs.flutter.dev/get-started/install
2. For each app (`customer_app` and `admin_app`), generate platform runner folders (`android/`, `ios/`) if needed and fetch dependencies:

```bash
# 1. Customer App
cd customer_app
flutter create . --platforms=ios,android
flutter pub get
flutter run

# 2. Admin App
cd ../admin_app
flutter create . --platforms=ios,android
flutter pub get
flutter run
```

> **Note:** Both apps currently run with rich, realistic in-memory state (including a 200-customer dataset in `admin_app`) so you can test every workflow immediately. To connect to your live backend (Firebase, Supabase, or REST API), replace the repository methods in `lib/services/app_state.dart`.
