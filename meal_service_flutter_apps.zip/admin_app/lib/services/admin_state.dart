import 'package:flutter/material.dart';
import '../models/admin_models.dart';

class AdminAppState extends ChangeNotifier {
  bool _isLoggedIn = false;
  bool _showTomorrow = false;
  final List<AdminCustomer> _customers = [];

  AdminAppState() {
    _seed200Customers();
  }

  bool get isLoggedIn => _isLoggedIn;
  bool get showTomorrow => _showTomorrow;
  List<AdminCustomer> get customers => List.unmodifiable(_customers);

  void login(String adminId) {
    _isLoggedIn = true;
    notifyListeners();
  }

  void logout() {
    _isLoggedIn = false;
    notifyListeners();
  }

  void setShowTomorrow(bool value) {
    _showTomorrow = value;
    notifyListeners();
  }

  void toggleMonthlyCashPaid(String customerId) {
    final idx = _customers.indexWhere((c) => c.id == customerId);
    if (idx != -1) {
      _customers[idx].monthlyAdvancePaid = !_customers[idx].monthlyAdvancePaid;
      notifyListeners();
    }
  }

  MealCountSummary getSummary({required bool forTomorrow}) {
    int b = 0, l = 0, d = 0, off = 0;
    for (final c in _customers) {
      final hasB = forTomorrow ? c.tomorrowBreakfast : c.todayBreakfast;
      final hasL = forTomorrow ? c.tomorrowLunch : c.todayLunch;
      final hasD = forTomorrow ? c.tomorrowDinner : c.todayDinner;
      if (hasB) b++;
      if (hasL) l++;
      if (hasD) d++;
      if (!hasB && !hasL && !hasD) off++;
    }
    return MealCountSummary(
      totalCustomers: _customers.length,
      breakfastCount: b,
      lunchCount: l,
      dinnerCount: d,
      dayOffCount: off,
    );
  }

  void _seed200Customers() {
    const firstNames = [
      'Aarav', 'Diya', 'Rohan', 'Ananya', 'Vikram', 'Sneha', 'Karthik', 'Meera',
      'Aditya', 'Pooja', 'Siddharth', 'Neha', 'Rahul', 'Kavya', 'Arjun', 'Priya',
      'Nikhil', 'Riya', 'Varun', 'Shreya'
    ];
    const lastNames = [
      'Sharma', 'Nair', 'Patel', 'Reddy', 'Iyer', 'Verma', 'Kulkarni', 'Rao',
      'Gupta', 'Menon'
    ];
    const hubs = [
      'Indiranagar TechPark',
      'Koramangala 4th Block',
      'HSR Layout Sector 2',
      'Whitefield ITPL',
      'MG Road Metro Hub',
    ];

    for (int i = 0; i < 200; i++) {
      final fn = firstNames[i % firstNames.length];
      final ln = lastNames[(i ~/ firstNames.length) % lastNames.length];
      final hub = hubs[i % hubs.length];

      // Realistic ~200 customer distribution across Breakfast, Lunch, Dinner, and Day Off
      final isDayOffToday = i % 16 == 0;
      final isDayOffTomorrow = i % 14 == 0;

      _customers.add(
        AdminCustomer(
          id: 'CUST-${1001 + i}',
          name: '$fn $ln',
          email: '${fn.toLowerCase()}.${ln.toLowerCase()}${i + 1}@example.com',
          phone: '+91 98${(10000000 + i * 3719).toString().substring(0, 8)}',
          address: 'Apt ${101 + i}, $hub, Bengaluru',
          preferredDeliveryAddress: i % 3 == 0 ? '$hub Office Reception' : 'Apt ${101 + i}, $hub, Bengaluru',
          monthlyAdvancePaid: i % 15 != 0,
          walletBalance: (i % 4) * 180.0,
          todayBreakfast: !isDayOffToday && (i % 5 != 0),
          todayLunch: !isDayOffToday && (i % 12 != 0),
          todayDinner: !isDayOffToday && (i % 7 != 0),
          tomorrowBreakfast: !isDayOffTomorrow && (i % 6 != 0),
          tomorrowLunch: !isDayOffTomorrow && (i % 11 != 0),
          tomorrowDinner: !isDayOffTomorrow && (i % 8 != 0),
        ),
      );
    }
  }
}
