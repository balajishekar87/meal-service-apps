import 'package:flutter/material.dart';
import '../models/admin_models.dart';
import '../services/admin_state.dart';

class CustomersDirectoryScreen extends StatefulWidget {
  final AdminAppState state;
  const CustomersDirectoryScreen({super.key, required this.state});

  @override
  State<CustomersDirectoryScreen> createState() => _CustomersDirectoryScreenState();
}

class _CustomersDirectoryScreenState extends State<CustomersDirectoryScreen> {
  String _query = '';
  String _filter = 'All'; // All, Paid, Due, Skipped Today

  @override
  Widget build(BuildContext context) {
    final filtered = widget.state.customers.where((c) {
      final matchesQuery = _query.isEmpty ||
          c.name.toLowerCase().contains(_query.toLowerCase()) ||
          c.phone.contains(_query) ||
          c.preferredDeliveryAddress.toLowerCase().contains(_query.toLowerCase());
      if (!matchesQuery) return false;

      switch (_filter) {
        case 'Paid':
          return c.monthlyAdvancePaid;
        case 'Due':
          return !c.monthlyAdvancePaid;
        case 'Skipped Today':
          return c.isSkippedToday;
        default:
          return true;
      }
    }).toList();

    return Scaffold(
      appBar: AppBar(title: Text('Customers (${filtered.length})')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search by name, phone, or delivery hub...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                isDense: true,
              ),
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: ['All', 'Paid', 'Due', 'Skipped Today'].map((f) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(f),
                    selected: _filter == f,
                    onSelected: (_) => setState(() => _filter = f),
                  ),
                );
              }).toList(),
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: filtered.length,
              itemBuilder: (context, idx) {
                final c = filtered[idx];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    onTap: () => _showCustomerDetail(context, c),
                    title: Row(
                      children: [
                        Expanded(child: Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold))),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            color: c.monthlyAdvancePaid ? Colors.green.shade50 : Colors.red.shade50,
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            c.monthlyAdvancePaid ? 'Cash Paid' : 'Cash Due',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: c.monthlyAdvancePaid ? Colors.green.shade800 : Colors.red.shade800,
                            ),
                          ),
                        ),
                      ],
                    ),
                    subtitle: Text(
                      '${c.phone} • ${c.preferredDeliveryAddress}\n'
                      'Today: ${_mealBadges(c.todayBreakfast, c.todayLunch, c.todayDinner)} • Wallet: ₹${c.walletBalance.toStringAsFixed(0)}',
                    ),
                    isThreeLine: true,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _mealBadges(bool b, bool l, bool d) {
    final items = [if (b) 'B', if (l) 'L', if (d) 'D'];
    return items.isEmpty ? 'Day Off' : items.join('+');
  }

  void _showCustomerDetail(BuildContext context, AdminCustomer c) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${c.name} (${c.id})', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _infoRow('Email', c.email),
            _infoRow('Phone', c.phone),
            _infoRow('Address', c.address),
            _infoRow('Preferred Delivery', c.preferredDeliveryAddress),
            _infoRow('Wallet Balance', '₹${c.walletBalance.toStringAsFixed(0)}'),
            _infoRow('Today Meals', _mealBadges(c.todayBreakfast, c.todayLunch, c.todayDinner)),
            _infoRow('Tomorrow Meals', _mealBadges(c.tomorrowBreakfast, c.tomorrowLunch, c.tomorrowDinner)),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () {
                  widget.state.toggleMonthlyCashPaid(c.id);
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.payments_outlined),
                label: Text(c.monthlyAdvancePaid ? 'Mark Monthly Cash as Due' : 'Record Monthly Cash Payment'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String val) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 130, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
          Expanded(child: Text(val)),
        ],
      ),
    );
  }
}
