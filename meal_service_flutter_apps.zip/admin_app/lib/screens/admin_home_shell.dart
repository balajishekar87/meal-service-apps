import 'package:flutter/material.dart';
import '../services/admin_state.dart';
import 'kitchen_counts_screen.dart';
import 'customers_directory_screen.dart';

class AdminHomeShell extends StatefulWidget {
  final AdminAppState state;
  const AdminHomeShell({super.key, required this.state});

  @override
  State<AdminHomeShell> createState() => _AdminHomeShellState();
}

class _AdminHomeShellState extends State<AdminHomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      KitchenCountsScreen(state: widget.state),
      CustomersDirectoryScreen(state: widget.state),
    ];

    return Scaffold(
      body: pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.analytics_outlined),
            selectedIcon: Icon(Icons.analytics),
            label: 'Meal Counts',
          ),
          NavigationDestination(
            icon: Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people),
            label: 'Customers (200)',
          ),
        ],
      ),
    );
  }
}
