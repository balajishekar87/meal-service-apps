import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/admin_state.dart';

class KitchenCountsScreen extends StatelessWidget {
  final AdminAppState state;
  const KitchenCountsScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final targetDate = state.showTomorrow ? now.add(const Duration(days: 1)) : now;
    final summary = state.getSummary(forTomorrow: state.showTomorrow);
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Kitchen Prep Counts'),
        actions: [
          IconButton(
            onPressed: state.logout,
            tooltip: 'Logout',
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Today (Locked)'), icon: Icon(Icons.lock_outline)),
              ButtonSegment(value: true, label: Text('Tomorrow (Live until 8 PM)'), icon: Icon(Icons.schedule)),
            ],
            selected: {state.showTomorrow},
            onSelectionChanged: (s) => state.setShowTomorrow(s.first),
          ),
          const SizedBox(height: 16),

          Card(
            color: cs.primary,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    DateFormat('EEEE, dd MMM yyyy').format(targetDate),
                    style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${summary.totalMealsToPrepare} Total Meals to Prepare',
                    style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${summary.totalCustomers} Registered Customers • ${summary.dayOffCount} Taking Day Off',
                    style: const TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          _MealCountCard(
            title: 'Breakfast',
            subtitle: '7:30 AM – 9:00 AM',
            count: summary.breakfastCount,
            total: summary.totalCustomers,
            icon: Icons.free_breakfast_outlined,
            color: Colors.orange.shade700,
          ),
          _MealCountCard(
            title: 'Lunch',
            subtitle: '12:30 PM – 2:00 PM',
            count: summary.lunchCount,
            total: summary.totalCustomers,
            icon: Icons.lunch_dining_outlined,
            color: Colors.green.shade700,
          ),
          _MealCountCard(
            title: 'Dinner',
            subtitle: '7:30 PM – 9:00 PM',
            count: summary.dinnerCount,
            total: summary.totalCustomers,
            icon: Icons.dinner_dining_outlined,
            color: Colors.indigo.shade700,
          ),
        ],
      ),
    );
  }
}

class _MealCountCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final int count;
  final int total;
  final IconData icon;
  final Color color;

  const _MealCountCard({
    required this.title,
    required this.subtitle,
    required this.count,
    required this.total,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final pct = total == 0 ? 0.0 : count / total;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: color.withValues(alpha: 0.12),
                  child: Icon(icon, color: color),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                      Text(subtitle, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
                    ],
                  ),
                ),
                Text(
                  '$count',
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: color),
                ),
              ],
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: pct,
              minHeight: 8,
              borderRadius: BorderRadius.circular(4),
              color: color,
              backgroundColor: Colors.grey.shade200,
            ),
          ],
        ),
      ),
    );
  }
}
