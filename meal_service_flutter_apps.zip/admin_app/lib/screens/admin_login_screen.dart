import 'package:flutter/material.dart';
import '../services/admin_state.dart';

class AdminLoginScreen extends StatefulWidget {
  final AdminAppState state;
  const AdminLoginScreen({super.key, required this.state});

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final _idCtrl = TextEditingController(text: 'kitchen.admin@dailytiffin.in');
  final _pinCtrl = TextEditingController(text: 'admin123');

  @override
  void dispose() {
    _idCtrl.dispose();
    _pinCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Icon(Icons.kitchen_rounded, size: 64, color: cs.primary),
                const SizedBox(height: 16),
                Text(
                  'Kitchen & Admin Portal',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  'View daily Breakfast, Lunch & Dinner preparation counts and manage customer accounts',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[700]),
                ),
                const SizedBox(height: 32),
                TextField(
                  controller: _idCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Admin ID / Email',
                    prefixIcon: Icon(Icons.admin_panel_settings_outlined),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _pinCtrl,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password',
                    prefixIcon: Icon(Icons.lock_outline),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 24),
                FilledButton.icon(
                  onPressed: () => widget.state.login(_idCtrl.text.trim()),
                  icon: const Icon(Icons.login),
                  label: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Text('Sign In to Kitchen Dashboard'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
