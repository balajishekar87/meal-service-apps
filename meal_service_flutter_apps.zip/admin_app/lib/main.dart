import 'package:flutter/material.dart';
import 'services/admin_state.dart';
import 'screens/admin_login_screen.dart';
import 'screens/admin_home_shell.dart';

void main() {
  runApp(const MealAdminApp());
}

class MealAdminApp extends StatefulWidget {
  const MealAdminApp({super.key});

  @override
  State<MealAdminApp> createState() => _MealAdminAppState();
}

class _MealAdminAppState extends State<MealAdminApp> {
  final AdminAppState _state = AdminAppState();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _state,
      builder: (context, _) {
        return MaterialApp(
          title: 'Daily Tiffin — Admin & Kitchen',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF1F4E79),
              brightness: Brightness.light,
            ),
            scaffoldBackgroundColor: const Color(0xFFF5F7FA),
            cardTheme: CardThemeData(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: Colors.grey.shade200),
              ),
            ),
          ),
          home: _state.isLoggedIn
              ? AdminHomeShell(state: _state)
              : AdminLoginScreen(state: _state),
        );
      },
    );
  }
}
