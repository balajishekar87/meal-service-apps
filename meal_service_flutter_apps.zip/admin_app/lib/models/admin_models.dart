class AdminCustomer {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String address;
  final String preferredDeliveryAddress;
  bool monthlyAdvancePaid;
  double walletBalance;

  // Today's locked requirements
  final bool todayBreakfast;
  final bool todayLunch;
  final bool todayDinner;

  // Tomorrow's incoming requirements (updates until 8:00 PM)
  final bool tomorrowBreakfast;
  final bool tomorrowLunch;
  final bool tomorrowDinner;

  AdminCustomer({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
    required this.preferredDeliveryAddress,
    required this.monthlyAdvancePaid,
    required this.walletBalance,
    required this.todayBreakfast,
    required this.todayLunch,
    required this.todayDinner,
    required this.tomorrowBreakfast,
    required this.tomorrowLunch,
    required this.tomorrowDinner,
  });

  bool get isSkippedToday => !todayBreakfast && !todayLunch && !todayDinner;
  bool get isSkippedTomorrow => !tomorrowBreakfast && !tomorrowLunch && !tomorrowDinner;
}

class MealCountSummary {
  final int totalCustomers;
  final int breakfastCount;
  final int lunchCount;
  final int dinnerCount;
  final int dayOffCount;

  const MealCountSummary({
    required this.totalCustomers,
    required this.breakfastCount,
    required this.lunchCount,
    required this.dinnerCount,
    required this.dayOffCount,
  });

  int get totalMealsToPrepare => breakfastCount + lunchCount + dinnerCount;
}
