import 'package:flutter/material.dart';
import 'services/app_state.dart';
import 'screens/login_screen.dart';
import 'screens/home_shell.dart';

void main() {
  runApp(const MealCustomerApp());
}

class MealCustomerApp extends StatefulWidget {
  const MealCustomerApp({super.key});

  @override
  State<MealCustomerApp> createState() => _MealCustomerAppState();
}

class _MealCustomerAppState extends State<MealCustomerApp> {
  final CustomerAppState _appState = CustomerAppState();

  @override
  void dispose() {
    _appState.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _appState,
      builder: (context, _) {
        return MaterialApp(
          title: 'Daily Tiffin — Customer',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF1B7A4E),
              brightness: Brightness.light,
            ),
            scaffoldBackgroundColor: const Color(0xFFF6F8F7),
            cardTheme: CardThemeData(
              elevation: 0,
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: BorderSide(color: Colors.grey.shade200),
              ),
            ),
          ),
          home: _appState.isLoggedIn
              ? HomeShell(state: _appState)
              : LoginScreen(state: _appState),
        );
      },
    );
  }
}
