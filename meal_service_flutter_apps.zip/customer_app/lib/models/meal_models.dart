enum MealType { breakfast, lunch, dinner }

extension MealTypeX on MealType {
  String get label {
    switch (this) {
      case MealType.breakfast:
        return 'Breakfast';
      case MealType.lunch:
        return 'Lunch';
      case MealType.dinner:
        return 'Dinner';
    }
  }

  String get timeWindow {
    switch (this) {
      case MealType.breakfast:
        return '7:30 AM – 9:00 AM';
      case MealType.lunch:
        return '12:30 PM – 2:00 PM';
      case MealType.dinner:
        return '7:30 PM – 9:00 PM';
    }
  }

  double get nominalPrice {
    switch (this) {
      case MealType.breakfast:
        return 40.0;
      case MealType.lunch:
        return 70.0;
      case MealType.dinner:
        return 70.0;
    }
  }
}

class CustomerProfile {
  String id;
  String name;
  String email;
  String phone;
  String address;
  String preferredDeliveryAddress;
  bool monthlyAdvancePaid;
  String activePlanMonth;
  double monthlyAdvanceAmount;

  CustomerProfile({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
    required this.preferredDeliveryAddress,
    required this.monthlyAdvancePaid,
    required this.activePlanMonth,
    required this.monthlyAdvanceAmount,
  });
}

class DailyMealRequirement {
  final DateTime date;
  bool breakfast;
  bool lunch;
  bool dinner;

  DailyMealRequirement({
    required this.date,
    this.breakfast = true,
    this.lunch = true,
    this.dinner = true,
  });

  bool get isDayOff => !breakfast && !lunch && !dinner;

  double get selectedTotal =>
      (breakfast ? MealType.breakfast.nominalPrice : 0) +
      (lunch ? MealType.lunch.nominalPrice : 0) +
      (dinner ? MealType.dinner.nominalPrice : 0);

  double get skippedRefundTotal =>
      (!breakfast ? MealType.breakfast.nominalPrice : 0) +
      (!lunch ? MealType.lunch.nominalPrice : 0) +
      (!dinner ? MealType.dinner.nominalPrice : 0);

  DailyMealRequirement copyWith({
    bool? breakfast,
    bool? lunch,
    bool? dinner,
  }) {
    return DailyMealRequirement(
      date: date,
      breakfast: breakfast ?? this.breakfast,
      lunch: lunch ?? this.lunch,
      dinner: dinner ?? this.dinner,
    );
  }
}

class WalletTransaction {
  final String id;
  final DateTime timestamp;
  final String title;
  final String description;
  final double amount;
  final bool isCredit;

  WalletTransaction({
    required this.id,
    required this.timestamp,
    required this.title,
    required this.description,
    required this.amount,
    required this.isCredit,
  });
}

class OrderRecord {
  final String orderId;
  final DateTime mealDate;
  final List<MealType> meals;
  final String deliveryAddress;
  final String status; // Confirmed, Delivered, Day Off (Refunded)
  final double value;

  OrderRecord({
    required this.orderId,
    required this.mealDate,
    required this.meals,
    required this.deliveryAddress,
    required this.status,
    required this.value,
  });
}

class WeeklyMenuDay {
  final String dayName;
  final String breakfastMenu;
  final String lunchMenu;
  final String dinnerMenu;

  const WeeklyMenuDay({
    required this.dayName,
    required this.breakfastMenu,
    required this.lunchMenu,
    required this.dinnerMenu,
  });
}
