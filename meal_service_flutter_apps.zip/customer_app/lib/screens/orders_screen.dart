import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/meal_models.dart';
import '../services/app_state.dart';

class OrdersScreen extends StatelessWidget {
  final CustomerAppState state;
  const OrdersScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Order Information')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: state.orders.length,
        itemBuilder: (context, index) {
          final order = state.orders[index];
          final mealNames = order.meals.isEmpty
              ? 'No meals (Day Off)'
              : order.meals.map((m) => m.label).join(', ');
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16),
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(DateFormat('EEE, dd MMM yyyy').format(order.mealDate),
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('₹${order.value.toStringAsFixed(0)}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 6),
                  Text('Meals: $mealNames'),
                  Text('Delivery: ${order.deliveryAddress}'),
                  const SizedBox(height: 6),
                  Chip(
                    label: Text(order.status, style: const TextStyle(fontSize: 12)),
                    visualDensity: VisualDensity.compact,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
