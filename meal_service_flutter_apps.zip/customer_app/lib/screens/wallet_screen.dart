import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/app_state.dart';

class WalletScreen extends StatelessWidget {
  final CustomerAppState state;
  const WalletScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final p = state.profile;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Wallet & Monthly Advance')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: cs.primary,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Available Wallet Credit', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 6),
                  Text(
                    '₹${state.walletBalance.toStringAsFixed(2)}',
                    style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${p.activePlanMonth} Cash Advance: ₹${p.monthlyAdvanceAmount.toStringAsFixed(0)} (${p.monthlyAdvancePaid ? "Paid" : "Pending"})',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('Refund & Credit History', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...state.transactions.map((txn) => Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: txn.isCredit ? Colors.green.shade50 : Colors.orange.shade50,
                    child: Icon(
                      txn.isCredit ? Icons.add : Icons.remove,
                      color: txn.isCredit ? Colors.green.shade700 : Colors.orange.shade700,
                    ),
                  ),
                  title: Text(txn.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${txn.description}\n${DateFormat('dd MMM, hh:mm a').format(txn.timestamp)}'),
                  isThreeLine: true,
                  trailing: Text(
                    '${txn.isCredit ? '+' : '-'}₹${txn.amount.toStringAsFixed(0)}',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: txn.isCredit ? Colors.green.shade700 : Colors.orange.shade800,
                    ),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
