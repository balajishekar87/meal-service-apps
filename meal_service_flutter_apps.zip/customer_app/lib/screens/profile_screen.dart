import 'package:flutter/material.dart';
import '../services/app_state.dart';

class ProfileScreen extends StatefulWidget {
  final CustomerAppState state;
  const ProfileScreen({super.key, required this.state});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _emailCtrl;
  late final TextEditingController _phoneCtrl;
  late final TextEditingController _addrCtrl;
  late final TextEditingController _prefAddrCtrl;

  @override
  void initState() {
    super.initState();
    final p = widget.state.profile;
    _nameCtrl = TextEditingController(text: p.name);
    _emailCtrl = TextEditingController(text: p.email);
    _phoneCtrl = TextEditingController(text: p.phone);
    _addrCtrl = TextEditingController(text: p.address);
    _prefAddrCtrl = TextEditingController(text: p.preferredDeliveryAddress);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _addrCtrl.dispose();
    _prefAddrCtrl.dispose();
    super.dispose();
  }

  void _save() {
    widget.state.updateProfile(
      name: _nameCtrl.text.trim(),
      email: _emailCtrl.text.trim(),
      phone: _phoneCtrl.text.trim(),
      address: _addrCtrl.text.trim(),
      preferredDeliveryAddress: _prefAddrCtrl.text.trim(),
    );
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Customer profile & delivery address updated')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Customer Profile'),
        actions: [
          IconButton(
            onPressed: widget.state.logout,
            tooltip: 'Logout',
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Full Name', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _emailCtrl, decoration: const InputDecoration(labelText: 'Email ID', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _phoneCtrl, decoration: const InputDecoration(labelText: 'Phone Number', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _addrCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Residential Address', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _prefAddrCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Preferred Delivery Address', border: OutlineInputBorder())),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_outlined),
            label: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Save Changes')),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: widget.state.logout,
            icon: const Icon(Icons.logout),
            label: const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Logout')),
          ),
        ],
      ),
    );
  }
}
