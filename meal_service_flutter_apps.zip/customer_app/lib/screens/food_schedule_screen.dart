import 'package:flutter/material.dart';
import '../services/app_state.dart';

class FoodScheduleScreen extends StatelessWidget {
  final CustomerAppState state;
  const FoodScheduleScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Weekly Food Schedule')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: state.weeklySchedule.length,
        itemBuilder: (context, index) {
          final day = state.weeklySchedule[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(day.dayName, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const Divider(height: 16),
                  _row('Breakfast', day.breakfastMenu),
                  const SizedBox(height: 6),
                  _row('Lunch', day.lunchMenu),
                  const SizedBox(height: 6),
                  _row('Dinner', day.dinnerMenu),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _row(String label, String menu) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 82, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
        Expanded(child: Text(menu)),
      ],
    );
  }
}
