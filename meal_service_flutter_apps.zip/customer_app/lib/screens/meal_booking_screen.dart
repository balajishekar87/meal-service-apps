import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/meal_models.dart';
import '../services/app_state.dart';

class MealBookingScreen extends StatefulWidget {
  final CustomerAppState state;
  const MealBookingScreen({super.key, required this.state});

  @override
  State<MealBookingScreen> createState() => _MealBookingScreenState();
}

class _MealBookingScreenState extends State<MealBookingScreen> {
  late DateTime _selectedDate;

  @override
  void initState() {
    super.initState();
    _selectedDate = widget.state.tomorrow;
  }

  void _applyUpdate(bool b, bool l, bool d) {
    final err = widget.state.updateMealRequirement(
      date: _selectedDate,
      breakfast: b,
      lunch: l,
      dinner: d,
    );
    if (err != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(err), backgroundColor: Colors.red.shade700),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = widget.state;
    final req = st.getRequirementForDate(_selectedDate);
    final isLocked = st.isLockedForDate(_selectedDate);
    final remaining = st.timeRemainingUntilTomorrowCutoff();
    final cs = Theme.of(context).colorScheme;

    final selectableDates = [
      st.tomorrow,
      st.dayAfterTomorrow,
      st.dayAfterTomorrow.add(const Duration(days: 1)),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Meal Requirements'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Chip(
              avatar: const Icon(Icons.account_balance_wallet, size: 16),
              label: Text('₹${st.walletBalance.toStringAsFixed(0)}'),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Live Date, Time & 8:00 PM Cutoff Banner
          Card(
            color: isLocked ? Colors.orange.shade50 : cs.primaryContainer.withValues(alpha: 0.45),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        DateFormat('EEE, dd MMM yyyy • hh:mm a').format(st.now),
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      Switch.adaptive(
                        value: st.simulateAfter8Pm,
                        onChanged: st.toggleSimulateAfter8Pm,
                      ),
                    ],
                  ),
                  Text(
                    st.simulateAfter8Pm ? 'Demo: Simulating After 8:00 PM' : 'Live Clock (Toggle switch to test 8 PM lock)',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(
                        isLocked ? Icons.lock_clock : Icons.timer_outlined,
                        size: 18,
                        color: isLocked ? Colors.orange.shade900 : cs.primary,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          isLocked
                              ? '8:00 PM cutoff passed for ${DateFormat('dd MMM').format(_selectedDate)}. Select a later date to edit.'
                              : 'Update tomorrow\'s meals before 8:00 PM (${remaining.inHours}h ${remaining.inMinutes % 60}m left).',
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            color: isLocked ? Colors.orange.shade900 : cs.onPrimaryContainer,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Date Selector
          Text('Select Date', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: selectableDates.map((d) {
              final selected = DateUtils.isSameDay(d, _selectedDate);
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Column(
                      children: [
                        Text(DateFormat('EEE').format(d)),
                        Text(DateFormat('dd MMM').format(d), style: const TextStyle(fontSize: 12)),
                      ],
                    ),
                    selected: selected,
                    onSelected: (_) => setState(() => _selectedDate = d),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 20),

          // Meal Toggles
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Meals for ${DateFormat('EEE, dd MMM').format(_selectedDate)}',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
              TextButton.icon(
                onPressed: isLocked ? null : () => _applyUpdate(false, false, false),
                icon: const Icon(Icons.event_busy, size: 18),
                label: const Text('Take Day Off'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _MealTile(
            meal: MealType.breakfast,
            selected: req.breakfast,
            locked: isLocked,
            onChanged: (v) => _applyUpdate(v, req.lunch, req.dinner),
          ),
          _MealTile(
            meal: MealType.lunch,
            selected: req.lunch,
            locked: isLocked,
            onChanged: (v) => _applyUpdate(req.breakfast, v, req.dinner),
          ),
          _MealTile(
            meal: MealType.dinner,
            selected: req.dinner,
            locked: isLocked,
            onChanged: (v) => _applyUpdate(req.breakfast, req.lunch, v),
          ),
          const SizedBox(height: 16),

          // Wallet Credit Summary
          Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: req.skippedRefundTotal > 0 ? Colors.green.shade50 : Colors.grey.shade100,
                child: Icon(
                  Icons.savings_outlined,
                  color: req.skippedRefundTotal > 0 ? Colors.green.shade700 : Colors.grey,
                ),
              ),
              title: Text(req.isDayOff ? 'Day Off — Full Refund Credited' : 'Daily Selection Summary'),
              subtitle: Text(
                'Active meals: ₹${req.selectedTotal.toStringAsFixed(0)} • '
                'Skipped credit to wallet: ₹${req.skippedRefundTotal.toStringAsFixed(0)}',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MealTile extends StatelessWidget {
  final MealType meal;
  final bool selected;
  final bool locked;
  final ValueChanged<bool> onChanged;

  const _MealTile({
    required this.meal,
    required this.selected,
    required this.locked,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: SwitchListTile(
        value: selected,
        onChanged: locked ? null : onChanged,
        title: Text('${meal.label} (₹${meal.nominalPrice.toStringAsFixed(0)})',
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${meal.timeWindow} • ${selected ? 'Included in monthly plan' : 'Skipped → ₹${meal.nominalPrice.toStringAsFixed(0)} to wallet'}'),
        secondary: Icon(
          meal == MealType.breakfast
              ? Icons.free_breakfast_outlined
              : meal == MealType.lunch
                  ? Icons.lunch_dining_outlined
                  : Icons.dinner_dining_outlined,
        ),
      ),
    );
  }
}
