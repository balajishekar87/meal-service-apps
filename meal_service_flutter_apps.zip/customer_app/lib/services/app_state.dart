import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/meal_models.dart';

class CustomerAppState extends ChangeNotifier {
  bool _isLoggedIn = false;
  DateTime _now = DateTime.now();
  Timer? _clockTimer;

  // Demo simulated cutoff override for testing after-8PM lock if desired
  bool _simulateAfter8Pm = false;

  late CustomerProfile _profile;
  double _walletBalance = 360.0;
  final Map<String, DailyMealRequirement> _requirements = {};
  final List<WalletTransaction> _transactions = [];
  final List<OrderRecord> _orders = [];

  CustomerAppState() {
    _seedInitialData();
    _clockTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _now = DateTime.now();
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    super.dispose();
  }

  bool get isLoggedIn => _isLoggedIn;
  DateTime get now => _simulateAfter8Pm
      ? DateTime(_now.year, _now.month, _now.day, 20, 30)
      : _now;
  bool get simulateAfter8Pm => _simulateAfter8Pm;
  CustomerProfile get profile => _profile;
  double get walletBalance => _walletBalance;
  List<WalletTransaction> get transactions => List.unmodifiable(_transactions);
  List<OrderRecord> get orders => List.unmodifiable(_orders);

  DateTime get tomorrow => DateTime(now.year, now.month, now.day).add(const Duration(days: 1));
  DateTime get dayAfterTomorrow => tomorrow.add(const Duration(days: 1));

  /// Previous-day 8:00 PM cutoff check for any target meal date
  bool isLockedForDate(DateTime targetDate) {
    final targetDay = DateTime(targetDate.year, targetDate.month, targetDate.day);
    final cutoff = targetDay.subtract(const Duration(days: 1)).add(const Duration(hours: 20));
    return !now.isBefore(cutoff);
  }

  Duration timeRemainingUntilTomorrowCutoff() {
    final cutoff = DateTime(now.year, now.month, now.day, 20, 0);
    if (now.isAfter(cutoff)) return Duration.zero;
    return cutoff.difference(now);
  }

  void toggleSimulateAfter8Pm(bool value) {
    _simulateAfter8Pm = value;
    notifyListeners();
  }

  String _dateKey(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

  DailyMealRequirement getRequirementForDate(DateTime date) {
    final key = _dateKey(date);
    return _requirements.putIfAbsent(
      key,
      () => DailyMealRequirement(date: DateTime(date.year, date.month, date.day)),
    );
  }

  void login(String identifier) {
    _isLoggedIn = true;
    notifyListeners();
  }

  void logout() {
    _isLoggedIn = false;
    notifyListeners();
  }

  /// Updates a single meal or full day off before 8:00 PM cutoff and adjusts wallet refund
  String? updateMealRequirement({
    required DateTime date,
    required bool breakfast,
    required bool lunch,
    required bool dinner,
  }) {
    if (isLockedForDate(date)) {
      return 'Cutoff passed (8:00 PM previous day). Tomorrow\'s meals are locked for kitchen prep.';
    }

    final current = getRequirementForDate(date);
    final prevRefund = current.skippedRefundTotal;

    final updated = current.copyWith(
      breakfast: breakfast,
      lunch: lunch,
      dinner: dinner,
    );
    final newRefund = updated.skippedRefundTotal;
    final delta = newRefund - prevRefund;

    _requirements[_dateKey(date)] = updated;
    _walletBalance += delta;

    final dateLabel = DateFormat('EEE, dd MMM').format(date);
    if (delta > 0) {
      _transactions.insert(
        0,
        WalletTransaction(
          id: 'TXN-${DateTime.now().millisecondsSinceEpoch}',
          timestamp: now,
          title: updated.isDayOff ? 'Day Off Wallet Credit' : 'Skipped Meal Refund',
          description: '$dateLabel — Credited for skipped meal(s)',
          amount: delta,
          isCredit: true,
        ),
      );
    } else if (delta < 0) {
      _transactions.insert(
        0,
        WalletTransaction(
          id: 'TXN-${DateTime.now().millisecondsSinceEpoch}',
          timestamp: now,
          title: 'Meal Re-enabled',
          description: '$dateLabel — Adjusted from wallet credit',
          amount: delta.abs(),
          isCredit: false,
        ),
      );
    }

    _syncUpcomingOrder(updated);
    notifyListeners();
    return null;
  }

  void updateProfile({
    required String name,
    required String email,
    required String phone,
    required String address,
    required String preferredDeliveryAddress,
  }) {
    _profile.name = name;
    _profile.email = email;
    _profile.phone = phone;
    _profile.address = address;
    _profile.preferredDeliveryAddress = preferredDeliveryAddress;
    notifyListeners();
  }

  void _syncUpcomingOrder(DailyMealRequirement req) {
    final key = _dateKey(req.date);
    _orders.removeWhere((o) => _dateKey(o.mealDate) == key);

    final meals = <MealType>[
      if (req.breakfast) MealType.breakfast,
      if (req.lunch) MealType.lunch,
      if (req.dinner) MealType.dinner,
    ];

    _orders.insert(
      0,
      OrderRecord(
        orderId: 'ORD-${key.replaceAll('-', '')}',
        mealDate: req.date,
        meals: meals,
        deliveryAddress: _profile.preferredDeliveryAddress,
        status: meals.isEmpty ? 'Day Off (Refunded to Wallet)' : 'Scheduled',
        value: req.selectedTotal,
      ),
    );
    _orders.sort((a, b) => b.mealDate.compareTo(a.mealDate));
  }

  final List<WeeklyMenuDay> weeklySchedule = const [
    WeeklyMenuDay(
      dayName: 'Monday',
      breakfastMenu: 'Idli, Sambar & Coconut Chutney',
      lunchMenu: 'Steamed Rice, Dal Tadka, Aloo Gobi, 2 Phulkas, Curd',
      dinnerMenu: '3 Chapati, Paneer Butter Masala, Jeera Rice',
    ),
    WeeklyMenuDay(
      dayName: 'Tuesday',
      breakfastMenu: 'Poha with Peanuts & Masala Chai',
      lunchMenu: 'Rajma Chawal, Bhindi Fry, 2 Phulkas, Salad',
      dinnerMenu: '3 Phulka, Mix Veg Curry, Dal Fry',
    ),
    WeeklyMenuDay(
      dayName: 'Wednesday',
      breakfastMenu: 'Masala Dosa & Tomato Chutney',
      lunchMenu: 'Sambar Rice, Cabbage Poriyal, Papad, Buttermilk',
      dinnerMenu: 'Veg Pulao, Raita, Chana Masala',
    ),
    WeeklyMenuDay(
      dayName: 'Thursday',
      breakfastMenu: 'Upma & Medu Vada',
      lunchMenu: 'Kadhi Pakora, Steamed Rice, Jeera Aloo, 2 Phulkas',
      dinnerMenu: '3 Chapati, Matar Paneer, Green Salad',
    ),
    WeeklyMenuDay(
      dayName: 'Friday',
      breakfastMenu: 'Aloo Paratha & Curd',
      lunchMenu: 'Chole, Pulao, 2 Phulkas, Boondi Raita',
      dinnerMenu: '3 Phulka, Dal Makhani, Veg Manchurian',
    ),
    WeeklyMenuDay(
      dayName: 'Saturday',
      breakfastMenu: 'Set Dosa & Vegetable Kurma',
      lunchMenu: 'Special Thali: Rice, Dal, Paneer, Sweet, 2 Phulkas',
      dinnerMenu: 'Khichdi, Kadhi, Roasted Papad',
    ),
    WeeklyMenuDay(
      dayName: 'Sunday',
      breakfastMenu: 'Poori Bhaji & Halwa',
      lunchMenu: 'Veg Biryani, Mirchi Ka Salan, Raita',
      dinnerMenu: '3 Chapati, Palak Paneer, Jeera Rice',
    ),
  ];

  void _seedInitialData() {
    _profile = CustomerProfile(
      id: 'CUST-1042',
      name: 'Aarav Sharma',
      email: 'aarav.sharma@example.com',
      phone: '+91 98765 43210',
      address: 'Flat 402, Greenview Residency, Indiranagar, Bengaluru',
      preferredDeliveryAddress: 'TechPark Tower B, Reception Desk, Bengaluru',
      monthlyAdvancePaid: true,
      activePlanMonth: DateFormat('MMMM yyyy').format(_now),
      monthlyAdvanceAmount: 5400.0,
    );

    final today = DateTime(_now.year, _now.month, _now.day);
    final tmrw = today.add(const Duration(days: 1));
    final dayAfter = today.add(const Duration(days: 2));

    _requirements[_dateKey(today)] = DailyMealRequirement(date: today);
    _requirements[_dateKey(tmrw)] = DailyMealRequirement(date: tmrw);
    _requirements[_dateKey(dayAfter)] = DailyMealRequirement(date: dayAfter);

    _orders.addAll([
      OrderRecord(
        orderId: 'ORD-${_dateKey(tmrw).replaceAll('-', '')}',
        mealDate: tmrw,
        meals: [MealType.breakfast, MealType.lunch, MealType.dinner],
        deliveryAddress: _profile.preferredDeliveryAddress,
        status: 'Scheduled',
        value: 180.0,
      ),
      OrderRecord(
        orderId: 'ORD-${_dateKey(today).replaceAll('-', '')}',
        mealDate: today,
        meals: [MealType.breakfast, MealType.lunch, MealType.dinner],
        deliveryAddress: _profile.preferredDeliveryAddress,
        status: 'In Preparation / Delivering',
        value: 180.0,
      ),
      OrderRecord(
        orderId: 'ORD-PREV-01',
        mealDate: today.subtract(const Duration(days: 2)),
        meals: [],
        deliveryAddress: _profile.preferredDeliveryAddress,
        status: 'Day Off (Refunded to Wallet)',
        value: 0.0,
      ),
      OrderRecord(
        orderId: 'ORD-PREV-02',
        mealDate: today.subtract(const Duration(days: 3)),
        meals: [MealType.breakfast, MealType.lunch, MealType.dinner],
        deliveryAddress: _profile.preferredDeliveryAddress,
        status: 'Delivered',
        value: 180.0,
      ),
    ]);

    _transactions.addAll([
      WalletTransaction(
        id: 'TXN-102',
        timestamp: today.subtract(const Duration(days: 3, hours: 6)),
        title: 'Day Off Wallet Credit',
        description: '${DateFormat('EEE, dd MMM').format(today.subtract(const Duration(days: 2)))} — Full day skipped before 8 PM',
        amount: 180.0,
        isCredit: true,
      ),
      WalletTransaction(
        id: 'TXN-101',
        timestamp: today.subtract(const Duration(days: 8, hours: 7)),
        title: 'Day Off Wallet Credit',
        description: '${DateFormat('EEE, dd MMM').format(today.subtract(const Duration(days: 7)))} — Full day skipped before 8 PM',
        amount: 180.0,
        isCredit: true,
      ),
    ]);
  }
}
